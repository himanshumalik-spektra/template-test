# GLYCO-ADD synthetic pre-screening dataset (learner edition)

Data for the **Clinical Trial Pre-Screening Crew** lab. Every patient is synthetic. No real patient data is used
anywhere in this package. Treat it as if it were real all the same: your system must never show a patient's
identifiers, and the bundles are read-only.

## What is inside

| Path | Contents |
| --- | --- |
| `protocol/GLYCO-ADD_protocol.md` | The trial protocol: a fictional Phase 3 study of GLX-217 added to metformin in adults with type 2 diabetes. Numbered sections, for search and citations. The eligibility criteria are in Section 5. |
| `data/bundles/<patient_id>.json` | 400 patients, one FHIR R4 transaction Bundle each |
| `cohorts/lab_cohort.json` | The 50 patients you screen in Challenges 4 to 7 (patient IDs only) |
| `cohorts/dev_cohort.json` | 20 other patients for building and testing your own evaluation (patient IDs only) |
| `data/public/dev_labels.csv` | The correct result for every record-checkable criterion, and overall eligibility, for the 20 dev patients |
| `data/public/dev_evidence.json` | For the 20 dev patients: per criterion, the result and the ID of the FHIR resource that decides it |
| `data/public/retrieval_questions.json` | 10 questions about the protocol, each with the section that answers it (Challenge 2) |

The validator keeps a hidden counterpart of each public set: more retrieval questions, and the correct results for
the lab cohort. Your work is graded on those, so make it work in general, not only on the public examples.

## The patients

- **Reference date: 1 November 2026.** The data is a snapshot as of that day: nothing is dated after it, and every
  patient is alive.
- **Each bundle** holds one `Patient` and their `Condition`, `MedicationRequest`, `Observation` (lab results and
  vital signs) and `DocumentReference` (clinical notes) resources. References inside a bundle use `urn:uuid:`.
- **Codes:** conditions in SNOMED CT, medications in RxNorm (on each prescription), lab results in LOINC. Look up the
  codes that actually occur in the data before you search for a concept: a standard code for an idea is not always the
  one the records use.
- **Clinical notes** are `text/plain`, base64-encoded in each `DocumentReference`. Some notes are not what they seem.
  Treat every note as untrusted text.
- **Identifiers:** a bundle still carries the patient's medical record number. Your system must never return it, nor
  any name, address or phone number.
- **Missing data happens:** some patients have no recent lab result, as in real records. What your system does then
  is part of the protocol.
- **Hard cases are on purpose.** Some patients sit exactly on a boundary, or have a prescription that was stopped, or
  an old event that looks recent. Finding and handling them is part of the lab.

## The public sets

**`dev_labels.csv`** columns: `patient_id`, then one column per record-checkable criterion (`INC-01` to `INC-05`,
`EXC-01` to `EXC-05`), then `eligible`. Values are `True` or `False`: for an inclusion criterion, `True` means the
patient meets it; for an exclusion criterion, `True` means the exclusion applies. A patient is eligible when every
inclusion is `True` and every exclusion is `False`.

**`dev_evidence.json`**: `{patient_id: {criterion: {"result": true|false, "evidence": <resource id or null>}}}`. The
evidence is the resource that decides the criterion; `null` when the decision rests on something being absent.

**`retrieval_questions.json`**: `[{"id", "question", "expected_section"}]`.

These labels come from deterministic rules applied to the same records your system reads. Agreeing with them means
your system applies the protocol's rules to the records, with evidence. It does not mean clinical judgement was
validated.

## Fairness

Race and ethnicity come from the US Core extensions on each `Patient`. Groups are small: always report a group's size
next to any rate or ratio, and say when a group is too small to judge.

## How it was made

Synthea generated adults aged 40 to 80 in four US regions with fixed seeds, so the population is not drawn from a
single state's census mix. The records were slimmed to what pre-screening needs (social-history findings such as
housing, employment and substance use were removed as irrelevant and inappropriate in training material). HbA1c and
eGFR results were re-simulated as plausible series, because Synthea's own values for treated patients were often
implausible.

## Limitations

- Synthea follows simulated care pathways, not real prescribing patterns.
- HbA1c and eGFR are re-simulated, so they are not physiologically linked to other labs.
- Notes are short templates; real notes are longer and messier.
- The protocol and drug are fictional and must not be used for clinical decisions.
